import threading
import traceback
from functools import wraps

global PREFIX  
PREFIX = ""
global PRINT_LOG
PRINT_LOG = True  
global LOG  
LOG = ""
lock = threading.Lock()


def log(*args, **kwargs):

    lock.acquire()  
    sep = " "  
    end = "\n"  
    if "sep" in kwargs:
        sep = kwargs["sep"]
    if "end" in kwargs:
        end = kwargs["end"]
    if "encoding" in kwargs:
        encoding = kwargs["encoding"]

    newLOG = PREFIX  
    for s in args[0:-1]: 
        newLOG += str(s) + sep
    newLOG += str(args[-1]) + end
    newLOG = newLOG.replace("\n", "\n" + PREFIX) 
    if PRINT_LOG:
        print(newLOG, end="")
    global LOG
    LOG += newLOG
    lock.release()


def test(name=""):


    def dec(func):
        @wraps(func)
        def w1(*args, **argv):
            global PREFIX
            try:
                log("--- {}".format(name))
                PREFIX += ("    ")
                return func(*args, **argv)
            except Exception as e:
                log('!!! {} 失败, 函数:"{}", 错误信息:{}, 参数:[args:{}, argv:{}]'.format(name, func.__name__, e, args, argv),
                    traceback.format_exc(), sep="\n")
            finally:
                PREFIX = PREFIX[:-4]

        return w1

    return dec
