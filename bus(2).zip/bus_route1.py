import csv
import json
import os
import string
import threading
import time
import traceback
from urllib.parse import quote

import box_test
import requests  
from bs4 import BeautifulSoup  
from xpinyin import Pinyin  

# box_test.PRINT_LOG=False

"""
城市公交路线爬取
"""
global KEY
KEY = ""
JSCODE =".."

@box_test.test("从高德地图获取某条公交路线")
def get_busRoute(cityName="北京", line="2路"):
    """
    从高德地图获取某条公交路线
    :param cityName: 城市名称
    :param line: 线路名称
    :return:返回公交信息
    """
    global KEY
    funcName = get_busRoute.__name__  
    url = quote(
        "https://restapi.amap.com/v3/bus/linename?s=rsv3&extensions=all&key={}&jscode={}&output=json&city={}&offset=1&keywords={}&platform=JS".format(
            KEY, JSCODE, cityName, line), safe=string.printable)
    n = 0  
    message = {'公交名称': line, "公交id": 0, "城市代码": 0, "公交类型": 0, "运营公司": 0, "起始站": 0, "终点站": 0, "距离": 0, '路线': 0,
               '路过的公交站': 0}  
    while True:
        try:
            data = 0  # 初始化，方便错误后输出
            response = requests.get(url, timeout=10)
            if response.status_code == 200:  # 成功
                data = json.loads(response.text)  
                if data["status"] == "1":  # 成功
                    buslines = data["buslines"][0] 

                    polyline = buslines["polyline"]
                    polyline = polyline.split(";")
                    polyline = [p.split(",") for p in polyline]

                    message = {'公交名称': buslines["name"], "公交id": buslines["id"], "城市代码": buslines["citycode"],
                               "公交类型": buslines["type"], "运营公司": buslines["company"], "起始站": buslines["start_stop"],
                               "终点站": buslines["end_stop"], "距离": buslines["distance"], '路线': polyline,
                               '路过的公交站': buslines["busstops"]}
                    box_test.log("{} {} 获取成功".format(cityName, line), funcName)
                    return message
            box_test.log("{}，{} 获取失败，状态码:{}，高德返回数据:{}".format(cityName, line, response.status_code, data), funcName)
            return message
        except TimeoutError:
            if n > 5:
                box_test.log("{}，{} 获取始终超时".format(cityName, line), funcName)
                return message
            else:
                n += 1
                box_test.log("{}，{} 超时重新尝试".format(cityName, line), funcName)
                time.sleep(n)

        except Exception as e:
            box_test.log("{}，{} 获取失败，高德返回数据:{}".format(cityName, line, data), traceback.format_exc(), sep="\n")
            return message


@box_test.test("从8864获取城市公交")
def get_busLine_from_8684(cityName, fileName=None):

    funcName = get_busLine_from_8684.__name__
    try:
        busName = []  
        baseUrl = quote("https://{}.8684.cn".format(cityName), safe=string.printable)
        url = baseUrl + "/list1"  
        n = 0  # 第0次
        while True:
            try:
                response = requests.get(url, timeout=10)
                if response.status_code == 200:  
                    data = response.text 
                    break
                else:
                    box_test.log("{} 第一页无法获取，状态码:{}".format(cityName, response.status_code), funcName)
                    return busName

            except TimeoutError:
                if n > 4:
                    box_test.log("{}，第一页获取超时，无法获取".format(cityName, funcName), funcName)
                    return busName
                else:
                    n += 1
                    box_test.log("{} 第一页获取超时重试".format(cityName), funcName)
                    time.sleep(n)
            except Exception as e:  
                box_test.log("{} 第一页无法获取".format(cityName), traceback.format_exc(), sep="\n")
                return busName
        html = BeautifulSoup(data, "html.parser")
        div = html.find("div", {"class": "category"})  
        busPage = []  # 所有的页
        for link in div:
            busPage.append(link.get("href"))  
        busPage = [i for i in busPage if i]  
        box_test.log("{}所有的页".format(cityName), busPage)
        for p in busPage:
            url = baseUrl + p
            n = 0  # 第0次尝试
            while True:
                try:
                    response = requests.get(url, timeout=10)
                    if response.status_code == 200:  # 成功
                        data = response.text
                    else:
                        box_test.log("{},{}页无法获取，状态码:{}".format(cityName, p, response.status_code), funcName)
                        break
                    html = BeautifulSoup(data, "html.parser")
                    div = html.find("div", {"class": "list clearfix"})
                    for link in div:
                        busName.append(link.get_text())
                    break
                except TimeoutError:
                    if n >= 4:
                        box_test.log("{},{}页获取超时失败".format(cityName, p), funcName)
                        break
                    else:
                        n += 1
                        box_test.log("{},{}页超时重试".format(cityName, p), funcName)
                        time.sleep(n)  
                except Exception as e:  
                    box_test.log("{},{}页无法获取".format(cityName, p), traceback.format_exc(), sep="\n")
                    break
        box_test.log(cityName, "所有公交获取成功", busName, funcName)
        if fileName:
            busName1 = [cityName] + busName
            with open(fileName, "w", newline="")as f:
                writer = csv.writer(f)
                writer.writerows([[i] for i in busName1])

    except Exception as e:
        box_test.log("{}获取失败".format(cityName), traceback.format_exc(), sep="\n")
    finally:
        return busName  


@box_test.test("获取一个城市的全部公交")
def get_all_busRoute_from_city(cityName, dirName):
    funName = get_all_busRoute_from_city.__name__  
    pinyin = Pinyin().get_pinyin(cityName).replace("-", "")
    busName = get_busLine_from_8684(Pinyin, dirName + "/" + "公交汇总.csv")
    busData = [['公交名称', "公交id", "城市代码", "公交类型", "运营公司", "起始站", "终点站", "距离", '路线', '路过的公交站']]

    lock = threading.Lock()  
    threads = []  
    activeThreads = []  
    messages = []  

    def get_busRoute_in_multiThread(cityName, b):
        message = get_busRoute(cityName, b)
        lock.acquire()
        messages.append(message)
        lock.release()

    if busName:
        for b in busName:
            t = threading.Thread(target=get_busRoute_in_multiThread, args=(cityName, b))
            threads.append(t)
        activeThreads.append(threads[0])  
        for t in threads:
            while True:  
                an = 0  
                for i in activeThreads:
                    if i.is_alive():
                        an += 1
                if an < 2:
                    activeThreads.append(t)
                    t.start()
                    break
                time.sleep(0.5)
        for t in threads:  
            t.join()
        busLinePath = dirName + "/公交路线"  
        busStopPath = dirName + "/公交站点"  
        if not os.path.exists(busLinePath):
            os.makedirs(busLinePath)
        if not os.path.exists(busStopPath):
            os.makedirs(busStopPath)
        for b, message in zip(busName, messages):
            try:
                busData.append([message[i] for i in busData[0]])
                if message["公交id"]:  
                    with open(busLinePath + "/" + b + message["公交名称"] + "公交路线.csv", "w", newline="") as f:
                        writer = csv.writer(f)
                        writer.writerow(["经度", "纬度"])
                        for i in message["路线"]:
                            writer.writerow(i)
                    with open(busStopPath + "/" + b + message["公交名称"] + "公交站.csv", "w", newline="") as f:
                        writer = csv.writer(f)
                        writer.writerow(["名字", "id", "经度", "纬度"])
                        for i in message["路过的公交站"]:
                            writer.writerow(
                                [i["name"], i["id"], i["location"].split(",")[0],
                                 i["location"].split(",")[1]])
                box_test.log("{} {} 成功".format(cityName, b), funName)
            except Exception as e:
                box_test.log("{} {} 错误".format(cityName, b), traceback.format_exc(), sep="\n")
        with open(dirName + "/" + cityName + ".csv", "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerows(busData)
    else:
        box_test.log("{} 获取公交失败".format(cityName), funName)


def test_key(key):
    global KEY
    KEY = key
    if get_busRoute()["公交id"] == 0:
        box_test.log("key值错误")
        return False
    else:
        return True


def main(key=None, cityName=None, dirName=None):
    global KEY
    if not key:
        KEY = input("输入高德‘web端’对应的key值: ")
        if not test_key(KEY):
            box_test.log("key值错误")
    if not cityName:
        cityName = input("输入要获取公交数据的城市: ")
    if not dirName:
        dirName = input("输入保存路径: ")
    get_all_busRoute_from_city(cityName, dirName)
    with open("./{}公交路线爬取日志.log".format(cityName), "w")as f:
        f.write(box_test.LOG)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        box_test.log(e)
    finally:
        with open("./bus_route日志.log", "w")as f:
            f.write(box_test.LOG)
